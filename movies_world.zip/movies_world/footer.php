<div class="" style="background-color:rgb(1,22,41);border-bottom:15px solid rgb(0,3,15);">
<div class="container">
<div class="row">
<div class="card my-4 text-white" style="line-height:18px;border:2px solid white;background-color:rgb(3,102,165);border-radius:10px;">
    <div class="card-body text-justify">
    <b>Watch Movies Online</b> Streaming free movies online from My Movies World is quick and simple. 
    Direct movie streaming to your computer or mobile device from the website does not require a subscription or credit card payments. Without standing in queue at the theatre, you may view the most recent HD releases. 
    You can watch hundreds of films without paying a subscription as long as your PC can stream video.
    </div>
</div>

<div class="card mb-2 text-white" style="line-height:20px;border:2px solid white;background-color:rgb(3,102,165);border-radius:10px;">
    <div class="card-body text-justify" >
    <b>Disclaimer</b> Movies world is completely legal and only contains links to other websites, 
    including those that offer free movie streaming (such as myMovies, 123yMovies, Jetlocker, MegaShare, 
    SockShare, allmyvideos, filenuke, vidxden, novamov, nowVideo, MegaVideo, gorillavid, yts, Primewire, 
    Solarmovie, Vidbull, vidto, Openload, Vodlocker, Putlockers.is, MyDownloadTube.com is not liable for the correctne
    ss, compliance, copyright, legality, or decency of any movies or media files (avi, mov, flv, mpg, mpeg, divx, dvd rip,
     mp3, mp4, torrent, ipod, psp) that are hosted on our site.
    Please get in touch with the proper media file owners or host sites if you have any legal concerns.
    </div>
</div>
<div class="text-white text-capitalize mx-auto d-block">
    <span class="badge badge-primary">download free movies</span>&nbsp;
    <span class="badge badge-primary">watch movies online free</span>&nbsp;
    <span class="badge badge-primary">free movies download</span>&nbsp;
    <span class="badge badge-primary">Movie torrent download</span>&nbsp;
    <span class="badge badge-primary">free movie download</span>&nbsp;
    <span class="badge badge-primary">myMovies</span>
</div>

<div class="col-md-12 text-center my-3">
    <a href="" id="bq1" title="Facebook" class="bg-white aas rounded-circle" style="padding:12px;"><i class="fa-brands fa-facebook-f ms1" style="font-size:25px;"></i></a>&nbsp;
    <a href="" id="bq2" title="Twitter" class="bg-white aas rounded-circle" style="padding:12px;"><i class="fa-brands fa-twitter ms2" style="font-size:25px;"></i></a>&nbsp;
    <a href="" id="bq3" title="Google" class="bg-white aas rounded-circle" style="padding:12px;"><i class="fa-brands fa-google ms3 " style="font-size:25px;"></i></a>&nbsp;
    <a href="" id="bq4" title="Pinterest" class="bg-white aas rounded-circle" style="padding:12px;"><i class="fa-brands fa-pinterest-p ms4" style="font-size:25px;"></i></a>
</div>
<div class="col-md-12 text-center my-3 text-white">
Copyright © <?=date('Y')?> Movies world. All Rights Reserved.
</div>
</div>
</div>
</div>

<script>
$(".aas").children().css("color","black");
$(document).ready(function(){
$("a").hover(function(){
$(this).css("color","rgb(3,102,165)");
},function(){
$(this).css("color","white");
});

$("#bq1").hover(function(){
$(".ms1").css("color","blue");
},function(){
$(".ms1").css("color","black");
});

$("#bq2").hover(function(){
$(".ms2").css("color","skyblue");
},function(){
$(".ms2").css("color","black");
});

$("#bq3").hover(function(){
$(".ms3").css("color","red");
},function(){
$(".ms3").css("color","black");
});

$("#bq4").hover(function(){
$(".ms4").css("color","red");
},function(){
$(".ms4").css("color","black");
});
});
</script>