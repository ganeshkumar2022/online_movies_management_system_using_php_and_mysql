<?php
$con=mysqli_connect("localhost","root","","movies_world");
?>